<?php

/** @generate-function-entries */

class PDOException extends RuntimeException
{
}

function pdo_drivers(): array {}
