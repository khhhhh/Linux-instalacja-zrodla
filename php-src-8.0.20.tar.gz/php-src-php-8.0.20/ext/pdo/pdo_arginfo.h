/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: 307a770b43157120de39093535ea4ee20c4524fa */

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_pdo_drivers, 0, 0, IS_ARRAY, 0)
ZEND_END_ARG_INFO()


ZEND_FUNCTION(pdo_drivers);


static const zend_function_entry ext_functions[] = {
	ZEND_FE(pdo_drivers, arginfo_pdo_drivers)
	ZEND_FE_END
};


static const zend_function_entry class_PDOException_methods[] = {
	ZEND_FE_END
};
