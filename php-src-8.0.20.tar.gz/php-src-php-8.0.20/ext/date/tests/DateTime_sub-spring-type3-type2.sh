#!/bin/sh

export TEST_PHP_SRCDIR='/home/aleh/build/php/8.0.20/php-src-php-8.0.20'
export CC='cc'
export TEST_PHP_EXECUTABLE='/home/aleh/build/php/8.0.20/php-src-php-8.0.20/sapi/cli/php'
export SHELL='/bin/bash'
export WSL_DISTRO_NAME='Debian'
export MAKE_TERMOUT='/dev/pts/0'
export NAME='HOME-PC'
export PWD='/home/aleh/build/php/8.0.20/php-src-php-8.0.20'
export LOGNAME='aleh'
export HOME='/home/aleh'
export LANG='en_US.UTF-8'
export WSL_INTEROP='/run/WSL/8_interop'
export LS_COLORS='rs=0:di=01;34:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:mi=00:su=37;41:sg=30;43:ca=30;41:tw=30;42:ow=34;42:st=37;44:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arc=01;31:*.arj=01;31:*.taz=01;31:*.lha=01;31:*.lz4=01;31:*.lzh=01;31:*.lzma=01;31:*.tlz=01;31:*.txz=01;31:*.tzo=01;31:*.t7z=01;31:*.zip=01;31:*.z=01;31:*.dz=01;31:*.gz=01;31:*.lrz=01;31:*.lz=01;31:*.lzo=01;31:*.xz=01;31:*.zst=01;31:*.tzst=01;31:*.bz2=01;31:*.bz=01;31:*.tbz=01;31:*.tbz2=01;31:*.tz=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.war=01;31:*.ear=01;31:*.sar=01;31:*.rar=01;31:*.alz=01;31:*.ace=01;31:*.zoo=01;31:*.cpio=01;31:*.7z=01;31:*.rz=01;31:*.cab=01;31:*.wim=01;31:*.swm=01;31:*.dwm=01;31:*.esd=01;31:*.jpg=01;35:*.jpeg=01;35:*.mjpg=01;35:*.mjpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.svg=01;35:*.svgz=01;35:*.mng=01;35:*.pcx=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.m2v=01;35:*.mkv=01;35:*.webm=01;35:*.webp=01;35:*.ogm=01;35:*.mp4=01;35:*.m4v=01;35:*.mp4v=01;35:*.vob=01;35:*.qt=01;35:*.nuv=01;35:*.wmv=01;35:*.asf=01;35:*.rm=01;35:*.rmvb=01;35:*.flc=01;35:*.avi=01;35:*.fli=01;35:*.flv=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.yuv=01;35:*.cgm=01;35:*.emf=01;35:*.ogv=01;35:*.ogx=01;35:*.aac=00;36:*.au=00;36:*.flac=00;36:*.m4a=00;36:*.mid=00;36:*.midi=00;36:*.mka=00;36:*.mp3=00;36:*.mpc=00;36:*.ogg=00;36:*.ra=00;36:*.wav=00;36:*.oga=00;36:*.opus=00;36:*.spx=00;36:*.xspf=00;36:'
export WAYLAND_DISPLAY='wayland-0'
export MFLAGS=''
export MAKEFLAGS=''
export TERM='xterm-256color'
export USER='aleh'
export MAKE_TERMERR='/dev/pts/0'
export DISPLAY=':0'
export SHLVL='2'
export MAKELEVEL='1'
export XDG_RUNTIME_DIR='/mnt/wslg/runtime-dir'
export WSLENV=''
export PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/usr/lib/wsl/lib:/mnt/c/texlive/2022/bin/win32:/mnt/c/Windows/system32:/mnt/c/Windows:/mnt/c/Windows/System32/Wbem:/mnt/c/Windows/System32/WindowsPowerShell/v1.0/:/mnt/c/Program Files (x86)/NVIDIA Corporation/PhysX/Common:/mnt/c/Program Files/NVIDIA Corporation/NVIDIA NvDLISR:/mnt/c/Program Files/Git/cmd:/mnt/c/Program Files/PuTTY/:/mnt/c/Program Files/Microsoft SQL Server/150/Tools/Binn/:/mnt/c/Program Files/Microsoft SQL Server/Client SDK/ODBC/170/Tools/Binn/:/mnt/c/Program Files/dotnet/:/mnt/c/Program Files (x86)/Microsoft SQL Server/150/DTS/Binn/:/mnt/c/Program Files/Azure Data Studio/bin:/mnt/c/Program Files/Docker/Docker/resources/bin:/mnt/c/ProgramData/DockerDesktop/version-bin:/mnt/c/texlive/2021/bin/win32:/mnt/c/Program Files/nodejs/:/mnt/c/Program Files/PowerShell/7/:/mnt/c/Windows/System32/OpenSSH/:/mnt/c/ProgramData/chocolatey/bin:/mnt/c/msys64/mingw64/bin:/mnt/c/Users/Aleh/AppData/Local/Programs/Python/Python310/Scripts/:/mnt/c/Users/Aleh/AppData/Local/Programs/Python/Python310/:/mnt/c/Users/Aleh/AppData/Local/Microsoft/WindowsApps:/mnt/c/Users/Aleh/AppData/Local/Programs/Microsoft VS Code/bin:/mnt/c/Users/Aleh/.dotnet/tools:/mnt/c/Program Files/heroku/bin:/mnt/c/Users/Aleh/AppData/Roaming/npm:/mnt/c/tools/neovim/nvim-win64/bin'
export HOSTTYPE='x86_64'
export PULSE_SERVER='/mnt/wslg/PulseServer'
export OLDPWD='/home/aleh/build/php/8.0.20'
export _='/home/aleh/build/php/8.0.20/php-src-php-8.0.20/sapi/cli/php'
export TEMP='/tmp'
export TEST_PHPDBG_EXECUTABLE='/home/aleh/build/php/8.0.20/php-src-php-8.0.20/sapi/phpdbg/phpdbg'
export REDIRECT_STATUS='1'
export QUERY_STRING=''
export PATH_TRANSLATED='/home/aleh/build/php/8.0.20/php-src-php-8.0.20/ext/date/tests/DateTime_sub-spring-type3-type2.php'
export SCRIPT_FILENAME='/home/aleh/build/php/8.0.20/php-src-php-8.0.20/ext/date/tests/DateTime_sub-spring-type3-type2.php'
export REQUEST_METHOD='GET'
export CONTENT_TYPE=''
export CONTENT_LENGTH=''
export TZ=''
export TEST_PHP_EXTRA_ARGS=' -n -c '\''/home/aleh/build/php/8.0.20/php-src-php-8.0.20/tmp-php.ini'\''  -d "output_handler=" -d "open_basedir=" -d "disable_functions=" -d "output_buffering=Off" -d "error_reporting=32767" -d "display_errors=1" -d "display_startup_errors=1" -d "log_errors=0" -d "html_errors=0" -d "track_errors=0" -d "report_memleaks=1" -d "report_zend_debug=0" -d "docref_root=" -d "docref_ext=.html" -d "error_prepend_string=" -d "error_append_string=" -d "auto_prepend_file=" -d "auto_append_file=" -d "ignore_repeated_errors=0" -d "precision=14" -d "serialize_precision=-1" -d "memory_limit=128M" -d "log_errors_max_len=0" -d "opcache.fast_shutdown=0" -d "opcache.file_update_protection=0" -d "opcache.revalidate_freq=0" -d "opcache.jit_hot_loop=1" -d "opcache.jit_hot_func=1" -d "opcache.jit_hot_return=1" -d "opcache.jit_hot_side_exit=1" -d "zend.assertions=1" -d "zend.exception_ignore_args=0" -d "zend.exception_string_param_max_len=15" -d "short_open_tag=0" -d "extension_dir=/home/aleh/build/php/8.0.20/php-src-php-8.0.20/modules/" -d "zend_extension=/home/aleh/build/php/8.0.20/php-src-php-8.0.20/modules/opcache.so" -d "session.auto_start=0"'
export HTTP_COOKIE=''

case "$1" in
"gdb")
    gdb --args /home/aleh/build/php/8.0.20/php-src-php-8.0.20/sapi/cli/php  -n -c '/home/aleh/build/php/8.0.20/php-src-php-8.0.20/tmp-php.ini'  -d "output_handler=" -d "open_basedir=" -d "disable_functions=" -d "output_buffering=Off" -d "error_reporting=32767" -d "display_errors=1" -d "display_startup_errors=1" -d "log_errors=0" -d "html_errors=0" -d "track_errors=0" -d "report_memleaks=1" -d "report_zend_debug=0" -d "docref_root=" -d "docref_ext=.html" -d "error_prepend_string=" -d "error_append_string=" -d "auto_prepend_file=" -d "auto_append_file=" -d "ignore_repeated_errors=0" -d "precision=14" -d "serialize_precision=-1" -d "memory_limit=128M" -d "log_errors_max_len=0" -d "opcache.fast_shutdown=0" -d "opcache.file_update_protection=0" -d "opcache.revalidate_freq=0" -d "opcache.jit_hot_loop=1" -d "opcache.jit_hot_func=1" -d "opcache.jit_hot_return=1" -d "opcache.jit_hot_side_exit=1" -d "zend.assertions=1" -d "zend.exception_ignore_args=0" -d "zend.exception_string_param_max_len=15" -d "short_open_tag=0" -d "extension_dir=/home/aleh/build/php/8.0.20/php-src-php-8.0.20/modules/" -d "zend_extension=/home/aleh/build/php/8.0.20/php-src-php-8.0.20/modules/opcache.so" -d "session.auto_start=0" -f "/home/aleh/build/php/8.0.20/php-src-php-8.0.20/ext/date/tests/DateTime_sub-spring-type3-type2.php"  2>&1
    ;;
"valgrind")
    USE_ZEND_ALLOC=0 valgrind $2 /home/aleh/build/php/8.0.20/php-src-php-8.0.20/sapi/cli/php  -n -c '/home/aleh/build/php/8.0.20/php-src-php-8.0.20/tmp-php.ini'  -d "output_handler=" -d "open_basedir=" -d "disable_functions=" -d "output_buffering=Off" -d "error_reporting=32767" -d "display_errors=1" -d "display_startup_errors=1" -d "log_errors=0" -d "html_errors=0" -d "track_errors=0" -d "report_memleaks=1" -d "report_zend_debug=0" -d "docref_root=" -d "docref_ext=.html" -d "error_prepend_string=" -d "error_append_string=" -d "auto_prepend_file=" -d "auto_append_file=" -d "ignore_repeated_errors=0" -d "precision=14" -d "serialize_precision=-1" -d "memory_limit=128M" -d "log_errors_max_len=0" -d "opcache.fast_shutdown=0" -d "opcache.file_update_protection=0" -d "opcache.revalidate_freq=0" -d "opcache.jit_hot_loop=1" -d "opcache.jit_hot_func=1" -d "opcache.jit_hot_return=1" -d "opcache.jit_hot_side_exit=1" -d "zend.assertions=1" -d "zend.exception_ignore_args=0" -d "zend.exception_string_param_max_len=15" -d "short_open_tag=0" -d "extension_dir=/home/aleh/build/php/8.0.20/php-src-php-8.0.20/modules/" -d "zend_extension=/home/aleh/build/php/8.0.20/php-src-php-8.0.20/modules/opcache.so" -d "session.auto_start=0" -f "/home/aleh/build/php/8.0.20/php-src-php-8.0.20/ext/date/tests/DateTime_sub-spring-type3-type2.php"  2>&1
    ;;
"rr")
    rr record $2 /home/aleh/build/php/8.0.20/php-src-php-8.0.20/sapi/cli/php  -n -c '/home/aleh/build/php/8.0.20/php-src-php-8.0.20/tmp-php.ini'  -d "output_handler=" -d "open_basedir=" -d "disable_functions=" -d "output_buffering=Off" -d "error_reporting=32767" -d "display_errors=1" -d "display_startup_errors=1" -d "log_errors=0" -d "html_errors=0" -d "track_errors=0" -d "report_memleaks=1" -d "report_zend_debug=0" -d "docref_root=" -d "docref_ext=.html" -d "error_prepend_string=" -d "error_append_string=" -d "auto_prepend_file=" -d "auto_append_file=" -d "ignore_repeated_errors=0" -d "precision=14" -d "serialize_precision=-1" -d "memory_limit=128M" -d "log_errors_max_len=0" -d "opcache.fast_shutdown=0" -d "opcache.file_update_protection=0" -d "opcache.revalidate_freq=0" -d "opcache.jit_hot_loop=1" -d "opcache.jit_hot_func=1" -d "opcache.jit_hot_return=1" -d "opcache.jit_hot_side_exit=1" -d "zend.assertions=1" -d "zend.exception_ignore_args=0" -d "zend.exception_string_param_max_len=15" -d "short_open_tag=0" -d "extension_dir=/home/aleh/build/php/8.0.20/php-src-php-8.0.20/modules/" -d "zend_extension=/home/aleh/build/php/8.0.20/php-src-php-8.0.20/modules/opcache.so" -d "session.auto_start=0" -f "/home/aleh/build/php/8.0.20/php-src-php-8.0.20/ext/date/tests/DateTime_sub-spring-type3-type2.php"  2>&1
    ;;
*)
    /home/aleh/build/php/8.0.20/php-src-php-8.0.20/sapi/cli/php  -n -c '/home/aleh/build/php/8.0.20/php-src-php-8.0.20/tmp-php.ini'  -d "output_handler=" -d "open_basedir=" -d "disable_functions=" -d "output_buffering=Off" -d "error_reporting=32767" -d "display_errors=1" -d "display_startup_errors=1" -d "log_errors=0" -d "html_errors=0" -d "track_errors=0" -d "report_memleaks=1" -d "report_zend_debug=0" -d "docref_root=" -d "docref_ext=.html" -d "error_prepend_string=" -d "error_append_string=" -d "auto_prepend_file=" -d "auto_append_file=" -d "ignore_repeated_errors=0" -d "precision=14" -d "serialize_precision=-1" -d "memory_limit=128M" -d "log_errors_max_len=0" -d "opcache.fast_shutdown=0" -d "opcache.file_update_protection=0" -d "opcache.revalidate_freq=0" -d "opcache.jit_hot_loop=1" -d "opcache.jit_hot_func=1" -d "opcache.jit_hot_return=1" -d "opcache.jit_hot_side_exit=1" -d "zend.assertions=1" -d "zend.exception_ignore_args=0" -d "zend.exception_string_param_max_len=15" -d "short_open_tag=0" -d "extension_dir=/home/aleh/build/php/8.0.20/php-src-php-8.0.20/modules/" -d "zend_extension=/home/aleh/build/php/8.0.20/php-src-php-8.0.20/modules/opcache.so" -d "session.auto_start=0" -f "/home/aleh/build/php/8.0.20/php-src-php-8.0.20/ext/date/tests/DateTime_sub-spring-type3-type2.php"  2>&1
    ;;
esac