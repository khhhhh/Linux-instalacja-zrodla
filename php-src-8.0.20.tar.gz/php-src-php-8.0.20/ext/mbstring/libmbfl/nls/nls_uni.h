#ifndef MBFL_NLS_UNI_H
#define MBFL_NLS_UNI_H

#include "mbfilter.h"

extern const mbfl_language mbfl_language_uni;

#endif /* MBFL_NLS_UNI_H */
