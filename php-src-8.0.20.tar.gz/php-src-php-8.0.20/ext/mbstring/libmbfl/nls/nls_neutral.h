#ifndef MBFL_NLS_NEUTRAL_H
#define MBFL_NLS_NEUTRAL_H

#include "mbfilter.h"

extern const mbfl_language mbfl_language_neutral;

#endif /* MBFL_NLS_NEUTRAL_H */
